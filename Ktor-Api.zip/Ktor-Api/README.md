# Tutorial: Tutorial: Simple Kotlin REST API with Ktor, Exposed and Kodein

This repository contains the code for my tutorial: [Tutorial: Simple Kotlin REST API with Ktor, Exposed and Kodein](https://stefangaller.at/app-development/backend/ktor-rest-api-exposed/)
